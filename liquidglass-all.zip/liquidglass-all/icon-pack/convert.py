"""Liquid glass icon pack converter. Usage: python convert.py <input_dir> <output_dir>"""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
from liquidglass import render
src, dst = sys.argv[1], sys.argv[2]
os.makedirs(dst, exist_ok=True)
for f in sorted(os.listdir(src)):
    if f.lower().endswith('.png'):
        render(os.path.join(src, f)).save(os.path.join(dst, f), optimize=True)
    else:
        open(os.path.join(dst, f), 'wb').write(open(os.path.join(src, f), 'rb').read())

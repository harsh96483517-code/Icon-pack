import numpy as np, functools
from PIL import Image
from scipy.ndimage import gaussian_filter, map_coordinates
SS=3; OUT=192; N=OUT*SS

@functools.lru_cache(maxsize=64)
def geom(x0,x1,y0,y1):
    sc=N/192
    c=((x0+x1)/2*sc,(y0+y1)/2*sc); h=((x1-x0)/2*sc,(y1-y0)/2*sc)
    def sdf(x,y,e=5.0):
        qx=np.abs(x-c[0])/h[0]; qy=np.abs(y-c[1])/h[1]
        return (np.power(qx**e+qy**e,1/e)-1)*min(h)
    yy,xx=np.mgrid[0:N,0:N].astype(np.float32)
    d=sdf(xx,yy); e=1.5*SS/2
    gx=sdf(xx+e,yy)-sdf(xx-e,yy); gy=sdf(xx,yy+e)-sdf(xx,yy-e)
    gl=np.sqrt(gx**2+gy**2)+1e-6; nx,ny=gx/gl,gy/gl
    depth=np.maximum(-d,0); bev=0.30*min(h)
    t=1-np.clip(depth/bev,0,1); amt=0.9*t**2*bev
    mask=1-np.clip((d+0.8*SS)/(1.6*SS),0,1)
    v=np.clip((yy-(c[1]-h[1]))/(2*h[1]),0,1)
    Lx,Ly=-0.6,-0.8
    nl=np.maximum(nx*Lx+ny*Ly,0); nb=np.maximum(-(nx*Lx+ny*Ly),0)
    rim=t**3; spec=rim*(0.30+0.70*nl**2)+0.25*rim*nb**2
    edge=1-np.clip(depth/(2.2*SS),0,1)
    a_body=np.clip(0.10+0.10*(1-v)+0.10*t**1.5+0.9*spec+0.22*edge,0,1).astype(np.float32)
    d2=sdf(xx,yy-6*SS)
    dsh=gaussian_filter(0.30*(1-np.clip(d2/(14*SS),0,1))**2*(d2>0),2*SS).astype(np.float32)
    ca=0.06*amt
    zx=(xx-c[0])*0.03; zy=(yy-c[1])*0.03
    offs=[(yy+ny*(amt+ca)+zy, xx+nx*(amt+ca)+zx),(yy+ny*amt+zy, xx+nx*amt+zx),(yy+ny*(amt-ca)+zy, xx+nx*(amt-ca)+zx)]
    return mask.astype(np.float32),a_body,dsh,offs

def render(path):
    src=np.array(Image.open(path).convert('RGBA')).astype(np.float32)/255
    A=src[...,3]
    ys,xs=np.where(A>0.03)
    if len(xs)==0: return Image.fromarray((src*255).astype(np.uint8),'RGBA')
    bb=(int(xs.min()),int(xs.max()+1),int(ys.min()),int(ys.max()+1))
    mask,a_body,dsh,offs=geom(*bb)
    glyph=gaussian_filter(np.clip((A-0.28)/0.72,0,1),0.4)
    G=np.array(Image.fromarray((glyph*255).astype(np.uint8)).resize((N,N),Image.BICUBIC)).astype(np.float32)/255
    g=[map_coordinates(G,o,order=1,mode='constant') for o in offs]
    ga=np.maximum(np.maximum(g[0],g[1]),g[2])
    sh=np.roll(gaussian_filter(g[1],1.5*SS),int(2.5*SS),0)
    sa=0.28*sh*(1-ga)
    # layer1 body (white), layer2 shadow (black), layer3 glyph (colored)
    a1=a_body
    ta=sa+a1*(1-sa)
    c1=(a1*(1-sa))/np.maximum(ta,1e-6)   # white fraction -> rgb gray level
    gaa=0.92*ga
    tb=gaa+ta*(1-gaa)
    prem_in=np.stack([0.92*g[i]+(c1*ta*(1-gaa)) for i in range(3)],-1)  # premultiplied
    in_a=tb
    prem=prem_in*mask[...,None]
    out_a=in_a*mask+dsh*(1-mask)
    res=np.concatenate([prem,out_a[...,None]],-1).reshape(OUT,SS,OUT,SS,4).mean((1,3))
    a=res[...,3:4]
    rgb=np.where(a>1e-4,res[...,:3]/np.maximum(a,1e-4),0)
    out=np.concatenate([np.clip(rgb,0,1),a],-1)
    return Image.fromarray((np.clip(out,0,1)*255+0.5).astype(np.uint8),'RGBA')

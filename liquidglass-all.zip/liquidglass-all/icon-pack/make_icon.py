"""Make a liquid glass icon for an app missing from the pack.
Usage: python make_icon.py "App Name" [out.png]   (uses the first letter(s) as the glyph)"""
import sys, os, numpy as np
from PIL import Image, ImageDraw, ImageFont
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from liquidglass import render

def monogram(name, size=192, bbox=(3, 190, 2, 190)):
    x0, x1, y0, y1 = bbox
    yy, xx = np.mgrid[0:size, 0:size].astype(np.float32)
    cx, cy, hx, hy = (x0+x1)/2, (y0+y1)/2, (x1-x0)/2, (y1-y0)/2
    q = (np.abs(xx-cx)/hx)**5 + (np.abs(yy-cy)/hy)**5
    tile = (q <= 1).astype(np.float32) * 0.17
    words = [w for w in name.replace('_', ' ').split() if w]
    text = (words[0][0] + (words[1][0] if len(words) > 1 else '')).upper() if words else '?'
    font = None
    for p in ['/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf']:
        if os.path.exists(p): font = ImageFont.truetype(p, 96 if len(text) == 1 else 78)
    g = Image.new('L', (size, size), 0)
    d = ImageDraw.Draw(g)
    d.text((size/2, size/2), text, font=font, fill=255, anchor='mm')
    glyph = np.array(g).astype(np.float32)/255
    a = np.maximum(tile, glyph)
    rgba = np.ones((size, size, 4), np.float32); rgba[..., 3] = a
    return Image.fromarray((rgba*255).astype(np.uint8), 'RGBA')

if __name__ == '__main__':
    name = sys.argv[1]
    out = sys.argv[2] if len(sys.argv) > 2 else name.lower().replace(' ', '_') + '.png'
    tmp = out + '.src.png'
    monogram(name).save(tmp)
    render(tmp).save(out, optimize=True)
    os.remove(tmp)

# Liquid glass: icon pack + daily calendar icon app

Based on the idea of [OverShifted/LiquidGlass](https://github.com/OverShifted/LiquidGlass) (MIT).

- `icon-pack/` : liquid glass icons for my apps (`icons/`), `mapping.csv`, and the Python tools
  (`convert.py`, `liquidglass.py`, `make_icon.py`) to convert more icons or make a letter icon for a missing app.
  Includes `calendar_1`..`calendar_31` (and `google_calendar_*`) date icons.
- `app/` : Android app that switches the calendar icon to today's date every midnight.
- `.github/workflows/build.yml` : builds the APK and publishes both the APK and the icon pack as downloads.

See `WORKFLOW.md` for the steps.

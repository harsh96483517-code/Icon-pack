# Workflow (Hinglish)

## 1. GitHub par daalo
1. Naya repo banao.
2. Is zip ka poora folder upload karo (`.github`, `app`, `icon-pack` sab).
3. **Actions** tab mein **Build APK and icon pack** chalega (3-5 minute). Na chale to **Run workflow** dabao.
4. Run ke neeche **Artifacts** mein do download milenge:
   - `DailyCalendarIcon-apk` : andar `app-debug.apk`
   - `LiquidGlass-icon-pack` : saare liquid glass icons

## 2. Phone par
1. `app-debug.apk` install karo aur **Daily Calendar** app ek baar kholo.
2. Settings > Apps > Daily Calendar > Battery > **Unrestricted**.
3. App mein **Turn on daily app icon** ya **Add changing shortcut to Home screen** dabao.
   Icon home screen se hat jaye to dusra tareeka (changing shortcut) use karo.

## 3. Icon pack
`icon-pack/icons/` ke icons apne icon pack project ya Theme Park mein use karo.
Date wale icons `calendar_1`..`calendar_31` hain. One UI Home ka Theme Park inhe roz nahi badalta,
isliye roz badalne ka kaam `app/` wala Daily Calendar app karta hai.

Kisi app ka icon nahi hai to:
`python icon-pack/make_icon.py "App Name" out.png`
